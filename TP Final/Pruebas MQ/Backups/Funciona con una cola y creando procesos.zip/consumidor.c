#include "comun.h"

int main() {

    // Define las variables para la cola de mensajes del barbero y clientes
    mqd_t cola;
    char buffer[MAX_BUFFER] = "Nada";
    struct mq_attr atrib;
    mensaje m;

    // Inicializa los atributos de la cola.
    atrib.mq_flags = 0;
    atrib.mq_maxmsg = 5;
    atrib.mq_msgsize = sizeof(mensaje);
    atrib.mq_curmsgs = 0;

    // Crea la cola.
    cola = mq_open(COLA, O_CREAT | O_RDWR, 0600, &atrib);

    while(1) {
        mq_receive(cola, (char *) &m, sizeof(mensaje), NULL);

        printf("Recibí del proceso: %d\n", m.pid);
    }

    return 0;
}
