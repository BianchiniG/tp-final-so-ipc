#include "comun.h"

int main() {

    // Define las variables para las colas de mensajes del barbero y clientes
    mqd_t cola;
    char buffer[MAX_BUFFER] = "Mensaje";
    struct mq_attr atrib;
    mensaje m;

    // Inicializa los atributos de la cola.
    atrib.mq_flags = 0;
    atrib.mq_maxmsg = 5;
    atrib.mq_msgsize = sizeof(mensaje);
    atrib.mq_curmsgs = 0;

    // Crea las colas.
    cola = mq_open(COLA, O_CREAT | O_RDWR, 0600, &atrib);

    while(1) {
        int estado;

        if (fork()){
            waitpid(0, &estado, 0);
        } else {
            m.pid = getpid();

            printf("Envia el proceso %d!\n", m.pid);
            mq_send(cola, (const char *) &m, sizeof(mensaje), 0);
        }

        sleep(5);
    }

    return 0;
}
